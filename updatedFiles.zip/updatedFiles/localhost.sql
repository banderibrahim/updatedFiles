-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 17, 2017 at 08:06 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `payment`
--
CREATE DATABASE IF NOT EXISTS `payment` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `payment`;

-- --------------------------------------------------------

--
-- Table structure for table `invoice`
--

CREATE TABLE `invoice` (
  `amount` int(11) NOT NULL,
  `response_code` varchar(5) NOT NULL,
  `card_number` varchar(50) NOT NULL,
  `card_holder_name` varchar(100) NOT NULL,
  `merchant_identifier` varchar(50) NOT NULL,
  `access_code` varchar(50) NOT NULL,
  `expiry_date` varchar(5) NOT NULL,
  `payment_option` varchar(50) NOT NULL,
  `customer_ip` varchar(50) NOT NULL,
  `language` varchar(5) NOT NULL,
  `eci` varchar(50) NOT NULL,
  `fort_id` varchar(50) NOT NULL,
  `command` varchar(50) NOT NULL,
  `response_message` varchar(50) NOT NULL,
  `merchant_reference` varchar(100) NOT NULL,
  `authorization_code` varchar(100) NOT NULL,
  `customer_email` varchar(100) NOT NULL,
  `token_name` varchar(50) NOT NULL,
  `currency` varchar(5) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `status` varchar(5) NOT NULL,
  `unit_price` int(11) NOT NULL,
  `service_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
