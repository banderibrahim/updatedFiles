package com.tadawul.model;

public class Result {

	 public Result(String imageName) {
		super();
		this.imageName = imageName;
	}

	String imageName;

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
}
