package com.tadawul.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tadawul.model.ImageListResult;
import com.tadawul.model.Result;
import com.tadawul.model.UploadResult;

@RestController
public class RestUploadController {

    private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);

    //Save the uploaded file to this folder
    private static String UPLOADED_FOLDER = "C://temp//";

    //Single file upload
    @RequestMapping("/uploadImage")
    public UploadResult uploadFile(
            @RequestParam("file") MultipartFile uploadfile) {

        logger.debug("Single file upload!");

        if (uploadfile.isEmpty()) {
        logger.debug("File is empty");
            return new UploadResult("fail","file is empty" , HttpStatus.OK.toString() , new Result(""));
        }

        try {

            saveUploadedFiles(Arrays.asList(uploadfile));

        } catch (IOException e) {
        	 logger.debug(e.getMessage());
            return new UploadResult("fail","general error" , HttpStatus.BAD_REQUEST.toString() , new Result(""));
        }

        return new UploadResult("success","" , HttpStatus.OK.toString() , new Result(uploadfile.getOriginalFilename()));
    }


    @RequestMapping(
    		  value = "/image",
    		  produces = MediaType.IMAGE_JPEG_VALUE
    		)
    public  byte[] getImage(@RequestParam(value="imageName") String imageName) throws IOException {
    	
    	File file = new File("C:/temp/"+imageName);
    	
    	InputStream in = new FileInputStream(file);
    		    
    	System.out.println("input stream " + in);
    		    
    	 return IOUtils.toByteArray(in);
    }
    
    @RequestMapping("/imageNames")
  	public  ImageListResult getImageNames() throws IOException {
  	
    	File folder = new File("C:/temp/");
    	File[] listOfFiles = folder.listFiles();
    	List<String> imageList = new ArrayList<String>();
    	for (int i = 0; i < listOfFiles.length; i++) {
    	      if (listOfFiles[i].isFile()) {
    	        System.out.println("File " + listOfFiles[i].getName());
    	        imageList.add(listOfFiles[i].getName());
    	      } else if (listOfFiles[i].isDirectory()) {
    	        System.out.println("Directory " + listOfFiles[i].getName());
    	      }
    };
    
    return new ImageListResult("Sucess" , "" , HttpStatus.OK.toString() , new Result(imageList));
  }
  
    //save file
    private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

        for (MultipartFile file : files) {

            if (file.isEmpty()) {
                continue; //next pls
            }

            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        }

    }
}
