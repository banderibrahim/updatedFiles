package com.tadawul.model;

public class ImageListResult {

	String status ;
	String errormessage ;
	String responsecode ;
	Result results ;
	
	public ImageListResult(String status, String errormessage,
			String responsecode, Result results) {
		super();
		this.status = status;
		this.errormessage = errormessage;
		this.responsecode = responsecode;
		this.results = results;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrormessage() {
		return errormessage;
	}

	public void setErrormessage(String errormessage) {
		this.errormessage = errormessage;
	}

	public String getResponsecode() {
		return responsecode;
	}

	public void setResponsecode(String responsecode) {
		this.responsecode = responsecode;
	}

	public Result getResults() {
		return results;
	}

	public void setResults(Result results) {
		this.results = results;
	}
	
}
