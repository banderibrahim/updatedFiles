package com.tadawul.model;

import java.util.List;



public class Result {
	
	String imageName;	
	List<String> images;

	 public Result() {
		super();
	}

	public Result(String imageName) {
		super();
		this.imageName = imageName;
	}
	 
	public Result(List<String> images) {
		super();
		this.images = images;
	}


	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}
		
	public List<String> getImages() {
		return images;
	}

	public void setImages(List<String> images) {
		this.images = images;
	}

}
