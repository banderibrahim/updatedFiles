package com.tadawul.model;

public class CommonResult {

	String status;
	String errorMessage;
	String responseCode;
	Result result;
	
	public CommonResult(String status, String errorMessage, String responseCode,
			Result result) {
		super();
		this.status = status;
		this.errorMessage = errorMessage;
		this.responseCode = responseCode;
		this.result = result;
	}

	public CommonResult() {
		super();
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public Result getResult() {
		return result;
	}

	public void setResult(Result result) {
		this.result = result;
	}
	
	
}
