package com.tadawul.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;







import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.tadawul.model.CommonResult;
import com.tadawul.model.Result;


@RestController
public class RestUploadController {

    private final Logger logger = LoggerFactory.getLogger(RestUploadController.class);

    //Save the uploaded file to this folder
    private static String UPLOADED_FOLDER = "C://temp//";

    //Single file upload
    @RequestMapping("/uploadImage")
    public CommonResult uploadFile(
            @RequestParam("file") MultipartFile uploadfile) {
        logger.debug("Single file upload!");

        if (uploadfile.isEmpty()) {
        logger.debug("File is empty");
            return new CommonResult("fail","file is empty" , HttpStatus.OK.toString() , new Result(""));
        }

        try {

            saveUploadedFiles(Arrays.asList(uploadfile));

        } catch (IOException e) {
        	 logger.debug(e.getMessage());
            return new CommonResult("fail","general error" , HttpStatus.BAD_REQUEST.toString() , new Result(""));
        }

        return new CommonResult("success","" , HttpStatus.OK.toString() , new Result(uploadfile.getOriginalFilename()));
    }


    @RequestMapping(
    		  value = "/image",
    		  produces = MediaType.IMAGE_JPEG_VALUE
    		)
    public  byte[] getImage(@RequestParam(value="imageName") String imageName) throws IOException {
    	
    	File file = new File("C:/temp/"+imageName);
    	
    	InputStream in = new FileInputStream(file);
    		    
    	System.out.println("input stream " + in);
    		    
    	 return IOUtils.toByteArray(in);
    }
    
    @RequestMapping("/imageNames")
  	public  CommonResult getImageNames() throws IOException {
  	
    	File folder = new File("C:/temp/");
    	File[] listOfFiles = folder.listFiles();
    	List<String> imageList = new ArrayList<String>();
    	for (int i = 0; i < listOfFiles.length; i++) {
    	      if (listOfFiles[i].isFile()) {
    	        System.out.println("File " + listOfFiles[i].getName());
    	        imageList.add(listOfFiles[i].getName());
    	      } else if (listOfFiles[i].isDirectory()) {
    	        System.out.println("Directory " + listOfFiles[i].getName());
    	      }
    };
    
    return new CommonResult("Sucess" , "" , HttpStatus.OK.toString() , new Result(imageList));
  }
  
    @RequestMapping("/updateFeedback")
    public CommonResult updateFeedback(@RequestParam(value="agendaID")String agendaID , @RequestParam(value="deviceId")String deviceId , @RequestParam(value="contentRating")String contentRating , @RequestParam(value="performanceRating")String performanceRating , @RequestParam(value="comments")String comments) throws FileNotFoundException{
    	
    	logger.debug("updateFeedback");
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
    	PrintWriter pw = new PrintWriter(new File("C://temp//"+"FeedBack" + deviceId + dateFormat.format(new Date()) + ".csv"));
    	StringBuilder sb = new StringBuilder();
    	sb.append("agendaID");
    	sb.append(',');
    	sb.append("deviceId");
    	sb.append(',');
    	sb.append("contentRating");
    	sb.append(',');
    	sb.append("performanceRating");
    	sb.append(',');
    	sb.append("comments");
    	sb.append('\n');

    	sb.append(agendaID);
    	sb.append(',');
    	sb.append(deviceId);
    	sb.append(',');
    	sb.append(contentRating);
    	sb.append(',');
    	sb.append(performanceRating);
    	sb.append(',');
    	sb.append(comments);
    	sb.append('\n');

    	pw.write(sb.toString());
    	pw.close();
    	return new CommonResult("Sucess" , "" , HttpStatus.OK.toString() , new Result());
    }
    
    //save file
    private void saveUploadedFiles(List<MultipartFile> files) throws IOException {

        for (MultipartFile file : files) {

            if (file.isEmpty()) {
                continue; //next pls
            }

            byte[] bytes = file.getBytes();
            Path path = Paths.get(UPLOADED_FOLDER + file.getOriginalFilename());
            Files.write(path, bytes);

        }

    }
}
