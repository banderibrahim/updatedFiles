<?php
include "DBconfig.php";


function addUser($un,$pass,$type){
    $conn = OpenConnection();
    if (!is_null($conn)){
            $query = "INSERT INTO `hospital`.`users` (`eid`, `pass`, `type`) VALUES ('".$un."', '".$pass."','".$type."');";
            $result = mysqli_query($conn, $query);
            CloseConnection($conn);            
            return $result;
    }
	else
		return false;
}

function AddValidSubscriber($fields){
    $conn = OpenConnection();
    if (!is_null($conn)){
			$date = new DateTime();
			$time = $date->getTimestamp();
        
            $query = "INSERT INTO `invoice` (`amount`, `response_code`, `card_number`, `card_holder_name`, `merchant_identifier`, `access_code`, `expiry_date`, `payment_option`, `customer_ip`, `language`, `eci`, `fort_id`, `command`, `response_message`, `merchant_reference`, `authorization_code`, `customer_email`, `token_name`, `currency`, `customer_name`, `status`,`unit_price`,`service_id`) VALUES (".$fields['amount'].", '".$fields['response_code']."', '".$fields['card_number']."','".$fields['card_holder_name']."','".$fields['merchant_identifier']."','".$fields['access_code']."','".$fields['expiry_date']."','".$fields['payment_option']."','".$fields['customer_ip']."','".$fields['language']."','".$fields['eci']."','".$fields['fort_id']."','".$fields['command']."','".$fields['response_message']."','".$fields['merchant_reference']."','".$fields['authorization_code']."','".$fields['customer_email']."','".$fields['token_name']."','".$fields['currency']."','".$fields['customer_name']."','".$fields['status']."',100,'EREF01');";
				$result = mysqli_query($conn, $query);
            CloseConnection($conn);            
            return $result;
    }
	else
		return false;
}
?>
