<?php

function OpenConnection(){
	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = '';
	$dbname = 'payment';
	$connection = mysqli_connect( $dbhost, $dbuser, $dbpass) or die('Could not connect to server.' );
	
	mysqli_query($connection,"SET NAMES 'utf8'"); 
	
    mysqli_select_db($connection,$dbname);	
	
    if(@mysqli_connect_errno())die('Error connecting to mysql');
	return $connection;				
}




function CloseConnection($conn){
	@mysqli_close($conn);
}
?>
